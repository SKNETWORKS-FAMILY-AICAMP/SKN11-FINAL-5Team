"use client"

import { useState, useEffect } from "react"
import axios from "axios"
import { format } from "date-fns"
import type {
  ScheduleEvent,
  NewEvent,
  PublishSchedule,
  AutomationTask,
} from "../types"

export function useSchedule(userId: number | null) {
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [automationTasks, setAutomationTasks] = useState<AutomationTask[]>([])

    useEffect(() => {
    console.log("📋 automationTasks 상태:", automationTasks)
  }, [automationTasks])

  const [scheduleEvents, setScheduleEvents] = useState<ScheduleEvent[]>([])
  const [googleEvents, setGoogleEvents] = useState<any[]>([])
  const [newEvent, setNewEvent] = useState<NewEvent>({
    title: "",
    date: "",
    time: "",
    description: "",
  })
  const [publishSchedule, setPublishSchedule] = useState<PublishSchedule>({
    date: "",
    time: "",
    type: "immediate",
  })

useEffect(() => {
  if (!userId) return

  const fetchAutomationTasks = async () => {
    try {
      const res = await axios.get("http://localhost:8005/workspace/automation", {
        params: { user_id: userId },
      })
      console.log("📦 API 응답 데이터:", res.data)
      setAutomationTasks(res.data?.data?.tasks || [])
    } catch (err) {
      console.error("자동화 작업 불러오기 실패:", err)
    }
  }

   const fetchGoogleCalendarEvents = async () => {
    const start = new Date()
    const end = new Date()
    end.setDate(end.getDate() + 30)

    const startDate = start.toISOString().split("T")[0]
    const endDate = end.toISOString().split("T")[0]
    console.log("📅 구글 캘린더 요청 날짜 범위 확인:", startDate, endDate)

    const events = await getGoogleCalendarEvents(userId, startDate, endDate)
    console.log("📅 구글 캘린더에서 불러온 이벤트:", events)
    setGoogleEvents(events)
  }

  fetchAutomationTasks()
  fetchGoogleCalendarEvents()
}, [userId])


  useEffect(() => {
    const events: ScheduleEvent[] = automationTasks.map((task) => ({
      id: task.task_id,
      title: task.title,
      date: task.scheduled_at ? format(new Date(task.scheduled_at), "yyyy-MM-dd") : "",
      time: task.scheduled_at ? format(new Date(task.scheduled_at), "HH:mm") : "",
      description: task.task_data?.content || "",
      type: "automation",
    }))
    setScheduleEvents(events)
  }, [automationTasks])
const getEventsForDate = (date: Date) => {
const dateStr = date.toISOString().slice(0, 10)

  const manualEvents = scheduleEvents.filter(event => event.date === dateStr)
  const automationEvents = automationTasks.filter(task => task.scheduled_at?.startsWith(dateStr))
  const googleDayEvents = googleEvents.filter(ev =>
    ev.start?.dateTime?.startsWith?.(dateStr) || ev.start?.date?.startsWith?.(dateStr)
  )

  return {
    manual: manualEvents,
    automation: automationEvents,
    google: googleDayEvents
  }
}
  const addEvent = (event: NewEvent) => {
    const newSchedule: ScheduleEvent = {
      id: Date.now(),
      title: event.title,
      date: event.date,
      time: event.time,
      description: event.description,
      type: "manual",
    }
    setScheduleEvents((prev) => [...prev, newSchedule])
    setNewEvent({ title: "", date: "", time: "", description: "" })
  }

  const deleteTask = async (taskId: number) => {
    try {
      await axios.delete(`http://localhost:8005/workspace/automation/${taskId}`)
      setAutomationTasks((prev) => prev.filter((task) => task.task_id !== taskId))
    } catch (err) {
      console.error("업무 삭제 실패:", err)
    }
  }

  const updateTask = async (task: AutomationTask) => {
    try {
      const res = await axios.put(`http://localhost:8005/workspace/automation/${task.task_id}`, task)
      console.log("업무 업데이트 완료:", res.data)
    } catch (err) {
      console.error("업무 업데이트 실패:", err)
    }
  }

const publishContent = async (
  title: string,
  task_data: any,
  type: string,
  toEmail?: string,
  tags: string[] = []
) => {
  if (!userId) {
    console.warn("❌ userId가 없습니다. 콘텐츠를 발행할 수 없습니다.")
    return false
  }

  try {
    let task_type = ""
    let endpoint = ""
    const status = "PENDING"

    if (type === "email") {
      task_type = "send_email"
      endpoint = "http://localhost:8005/workspace/automation/ai"

      // email 전용 task_data 재구성
      task_data = {
        to_emails: [toEmail],
        subject: title,
        body: task_data.content,       // email은 본문이 따로 있으니 맞춰줌
        html_body: task_data.content,
        platform: "email",
      }
    } else if (type === "instagram") {
      task_type = "sns_publish_instagram"
      endpoint = "http://localhost:8005/workspace/automation/ai"

      task_data = {
        ...task_data,
        platform: "instagram",
        searched_hashtags: tags,
      }
    } else if (type === "naver") {
      task_type = "sns_publish_blog"
      endpoint = "http://localhost:8005/workspace/automation/ai"

      task_data = {
        ...task_data,
         platform: "naver_blog",
        top_keywords: tags,
      }
    } else {
      console.warn("❌ 알 수 없는 type 값:", type)
      return false
    }

    const automationRes = await axios.post(endpoint, {
      user_id: userId,
      task_type,
      title,
      task_data,
      platform: task_data.platform,
      content: task_data.full_content || task_data.post_content || "",  // 수동용
      scheduled_at: null,
      status,
    })

    console.log("📌 자동화 등록 완료:", automationRes.data)
    return true
  } catch (err: any) {
    console.error("❌ 콘텐츠 발행 실패:", err?.response?.data || err.message || err)
    return false
  }
}

async function getGoogleCalendarEvents(userId: number, start: string, end: string) {
  if (!userId || !start || !end) {
    console.warn("❗ 필수 파라미터가 누락되었습니다:", { userId, start, end })
    return []
  }

  try {
    const res = await axios.get("http://localhost:8005/events", {
      params: {
        user_id: userId,
        start_date: start,  
        end_date: end,      
        calendar_id: "primary"
      },
    })
    return res.data.events || []
  } catch (err) {
    console.error("구글 캘린더 일정 조회 실패", err)
    
    return []
  }
}

  return {
    selectedDate,
    setSelectedDate,
    automationTasks,
    scheduleEvents,
    newEvent,
    setNewEvent,
    publishSchedule,
    setPublishSchedule,
    getEventsForDate,
    addEvent,
    deleteTask,
    updateTask,
    googleEvents,
    publishContent,
  }
}
