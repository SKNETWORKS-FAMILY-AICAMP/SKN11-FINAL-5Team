"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { FileText, Instagram, Plus, Save, Send, Loader2 } from "lucide-react"
import type { ContentForm, PublishSchedule, AutomationTask } from "../types"

interface ContentEditorProps {
  contentForm: ContentForm
  setContentForm: (form: ContentForm) => void
  selectedTemplate: AutomationTask | null
  publishSchedule: PublishSchedule
  setPublishSchedule: (schedule: PublishSchedule) => void
  onSave: () => void
  onPublish: () => void
  saveGeneratedContent: () => void
  onGenerateContent?: (
    keywords: string,
    platform: string
  ) => Promise<{ title: string; content: string; tags: string[] }>
  onSetTags?: (tags: string[]) => void
  showContentGenerator?: boolean
  tags: string[]
}

export function ContentEditor({
  contentForm,
  setContentForm,
  selectedTemplate,
  publishSchedule,
  setPublishSchedule,
  saveGeneratedContent,
  onPublish,
  onGenerateContent,
  onSetTags,
  tags,
  showContentGenerator = false,
}: ContentEditorProps) {
  const [isContentGeneratorOpen, setIsContentGeneratorOpen] = useState(false)
  const [tagInput, setTagInput] = useState("")
  const [localTags, setLocalTags] = useState<string[]>([])
  const [isAccountModalOpen, setIsAccountModalOpen] = useState(false)
  const [accountInfo, setAccountInfo] = useState({ username: "", password: "" })
  const [isLoading, setIsLoading] = useState(false)
  const [contentGeneratorForm, setContentGeneratorForm] = useState({
    platform: "instagram",
    keywords: "",
  })

  useEffect(() => {
    setLocalTags(tags)
  }, [tags])

  const handleGenerateContent = async () => {
    if (!onGenerateContent) return

    const keyword = contentGeneratorForm.keywords.trim()
    if (!keyword) {
      alert("키워드를 입력해주세요!")
      return
    }

    // ✅ 초기화 & 로딩 시작
    setContentForm({ title: "", content: "" })
    setIsLoading(true)

    try {
      const { content, title, tags } = await onGenerateContent(
        keyword,
        contentGeneratorForm.platform
      )

      setContentForm({ title, content })
      setLocalTags(tags)
      onSetTags?.(tags)
      setIsContentGeneratorOpen(false)
      setContentGeneratorForm({ platform: "instagram", keywords: "" })
    } catch (err) {
      console.error("❌ 콘텐츠 생성 실패:", err)
      alert("콘텐츠 생성 중 오류가 발생했습니다.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleAccountConnect = () => {
    console.log("계정 연결:", accountInfo)
    setIsAccountModalOpen(false)
  }

  return (
    <Card className="rounded-xl border-0 shadow-sm bg-white">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <FileText className="h-4 w-4 text-blue-600" />
            <span className="text-base">콘텐츠 에디터</span>
          </div>
          <div className="flex items-center space-x-2">
            {showContentGenerator && (
              <Button
                onClick={() => setIsContentGeneratorOpen(!isContentGeneratorOpen)}
                className="bg-blue-500 hover:bg-blue-600 rounded-lg text-sm px-3 py-2 h-8"
              >
                <Plus className="h-3 w-3 mr-1" />
                콘텐츠 생성
              </Button>
            )}
            <Button
              onClick={saveGeneratedContent}
              variant="outline"
              className="rounded-lg text-sm px-3 py-2 h-8 bg-transparent"
            >
              <Save className="h-3 w-3 mr-1" />
              저장
            </Button>
            <Button
              onClick={onPublish}
              className="bg-green-500 hover:bg-green-600 rounded-lg text-sm px-3 py-2 h-8"
            >
              <Send className="h-3 w-3 mr-1" />
              발행
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {showContentGenerator && isContentGeneratorOpen && (
          <Card className="border-2 border-blue-200 bg-blue-50 rounded-lg">
            <CardContent className="p-4">
              <Label>플랫폼 선택</Label>
              <div className="flex space-x-4 mb-4">
                {["instagram", "naver"].map((platform) => (
                  <label key={platform} className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="radio"
                      value={platform}
                      checked={contentGeneratorForm.platform === platform}
                      onChange={(e) =>
                        setContentGeneratorForm({ ...contentGeneratorForm, platform: e.target.value })
                      }
                    />
                    {platform === "instagram" ? (
                      <Instagram className="h-4 w-4 text-pink-600" />
                    ) : (
                      <FileText className="h-4 w-4 text-green-600" />
                    )}
                    <span className="text-sm">{platform}</span>
                  </label>
                ))}
              </div>

              {contentGeneratorForm.platform === "instagram" && (
                <div className="mb-4">
                  <Dialog open={isAccountModalOpen} onOpenChange={setIsAccountModalOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="bg-transparent">
                        인스타그램 계정 연결
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>인스타그램 계정 연결</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-2">
                        <Label htmlFor="username">아이디</Label>
                        <Input
                          id="username"
                          value={accountInfo.username}
                          onChange={(e) => setAccountInfo({ ...accountInfo, username: e.target.value })}
                        />
                        <Label htmlFor="password">비밀번호</Label>
                        <Input
                          id="password"
                          type="password"
                          value={accountInfo.password}
                          onChange={(e) => setAccountInfo({ ...accountInfo, password: e.target.value })}
                        />
                      </div>
                      <div className="flex justify-end space-x-2 mt-4">
                        <Button variant="outline" onClick={() => setIsAccountModalOpen(false)}>
                          취소
                        </Button>
                        <Button
                          onClick={handleAccountConnect}
                          className="bg-pink-500 hover:bg-pink-600 text-white"
                          disabled={!accountInfo.username || !accountInfo.password}
                        >
                          연결하기
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              )}

              <Label>키워드</Label>
              <Input
                value={contentGeneratorForm.keywords}
                onChange={(e) =>
                  setContentGeneratorForm({ ...contentGeneratorForm, keywords: e.target.value })
                }
              />
              <Button onClick={handleGenerateContent} className="mt-4 w-full bg-blue-600 text-white">
                {isLoading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" /> 생성 중...
                  </>
                ) : (
                  "콘텐츠 생성하기"
                )}
              </Button>
            </CardContent>
          </Card>
        )}

        <div>
          <Label htmlFor="title">제목</Label>
          <Input
            id="title"
            value={contentForm.title}
            onChange={(e) => setContentForm({ ...contentForm, title: e.target.value })}
          />
        </div>
        <div>
          <Label htmlFor="content">본문</Label>
          <Textarea
            id="content"
            className="min-h-[200px]"
            value={contentForm.content}
            onChange={(e) => setContentForm({ ...contentForm, content: e.target.value })}
          />
        </div>
      </CardContent>
    </Card>
  )
}
