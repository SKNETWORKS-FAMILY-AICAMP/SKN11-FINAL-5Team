"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { CalendarIcon, Plus, Search, Clock, ChevronLeft, ChevronRight } from "lucide-react"
import { ScheduleSidebar } from "./ScheduleSidebar"
import type { ScheduleEvent, AutomationTask } from "../types"
import type { NewEvent } from "@/app/workspace/types"

interface CalendarProps {
  selectedDate?: Date
  setSelectedDate: (date: Date) => void
  scheduleEvents: ScheduleEvent[]
  automationTasks: AutomationTask[]
  googleEvents: any[]
  newEvent: NewEvent
  setNewEvent: (event: NewEvent) => void
  onAddEvent: (event: NewEvent) => void
  userId: number
}

export function Calendar({
  selectedDate,
  setSelectedDate,
  scheduleEvents = [],
  automationTasks = [],
  googleEvents = [],
  newEvent,
  setNewEvent,
  onAddEvent,
  userId,
}: CalendarProps) {
  const [isEventDialogOpen, setIsEventDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [currentDate, setCurrentDate] = useState(new Date())

  const handleAddEvent = () => {
    onAddEvent(newEvent)
    setIsEventDialogOpen(false)
  }

  const getEventsForDate = (date: Date) => {
    const selectedStr = date.toISOString().split("T")[0]
    const manual = scheduleEvents
      .filter((e: any) => {
        const d = e.date?.split("T")[0] || e.date
        return d === selectedStr
      })
      .map((event: any) => ({
        id: event.id || `event-${Math.random()}`,
        title: event.title || "제목 없음",
        time: event.time || "종일",
        description: event.description || "",
        date: event.date || "",
        type: "manual" as const,
      }))

    const automation = automationTasks.filter((task) => task.scheduled_at === selectedStr)
    return { manual, automation }
  }

  const getDaysInMonth = (date: Date) => {
    const year = date.getFullYear()
    const month = date.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const daysInMonth = lastDay.getDate()
    const startingDayOfWeek = firstDay.getDay()

    const days = []

    // Previous month's trailing days
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      const prevDate = new Date(year, month, -i)
      days.push({
        date: prevDate,
        isCurrentMonth: false,
        isToday: false,
        hasEvents: false,
      })
    }

    // Current month's days
    for (let day = 1; day <= daysInMonth; day++) {
      const dayDate = new Date(year, month, day)
      const isToday = dayDate.toDateString() === new Date().toDateString()
      const hasEvents = getEventsForDate(dayDate).manual.length > 0 || getEventsForDate(dayDate).automation.length > 0

      days.push({
        date: dayDate,
        isCurrentMonth: true,
        isToday,
        hasEvents,
      })
    }

    // Next month's leading days
    const remainingDays = 42 - days.length
    for (let day = 1; day <= remainingDays; day++) {
      const nextDate = new Date(year, month + 1, day)
      days.push({
        date: nextDate,
        isCurrentMonth: false,
        isToday: false,
        hasEvents: false,
      })
    }

    return days
  }

  const navigateMonth = (direction: "prev" | "next") => {
    setCurrentDate((prev) => {
      const newDate = new Date(prev)
      if (direction === "prev") {
        newDate.setMonth(prev.getMonth() - 1)
      } else {
        newDate.setMonth(prev.getMonth() + 1)
      }
      return newDate
    })
  }

  const days = getDaysInMonth(currentDate)
  const weekDays = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      {/* 좌측: 일정 캘린더 - 2/3 공간 차지, 오른쪽과 동일한 높이 */}
      <div className="lg:col-span-2">
        <Card className="rounded-xl border-0 shadow-sm bg-white h-[700px] flex flex-col">
          <CardHeader className="pb-3 flex-shrink-0">
            <div className="flex flex-row justify-between items-center">
              <div className="flex items-center space-x-2">
                <CalendarIcon className="h-4 w-4 text-green-600" />
                <span className="text-base font-semibold">일정 캘린더</span>
                <div className="flex items-center space-x-1 text-xs">
                  <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                  <span className="text-purple-600">사용자 일정</span>
                  <div className="w-2 h-2 bg-red-500 rounded-full ml-2"></div>
                  <span className="text-red-600">자동화 업무</span>
                </div>
              </div>
              <Dialog open={isEventDialogOpen} onOpenChange={setIsEventDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-green-500 hover:bg-green-600 rounded-lg text-sm px-3 py-2 h-8">
                    <Plus className="h-3 w-3 mr-1" /> 일정 등록
                  </Button>
                </DialogTrigger>
                <DialogContent className="rounded-xl">
                  <DialogHeader>
                    <DialogTitle>새 일정 등록</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <Input
                      placeholder="제목"
                      value={newEvent.title}
                      onChange={(e) => setNewEvent({ ...newEvent, title: e.target.value })}
                    />
                    <Input
                      type="date"
                      value={newEvent.date}
                      onChange={(e) => setNewEvent({ ...newEvent, date: e.target.value })}
                    />
                    <Input
                      type="time"
                      value={newEvent.time}
                      onChange={(e) => setNewEvent({ ...newEvent, time: e.target.value })}
                    />
                    <Textarea
                      placeholder="설명"
                      value={newEvent.description}
                      onChange={(e) => setNewEvent({ ...newEvent, description: e.target.value })}
                    />
                    <Button
                      onClick={handleAddEvent}
                      disabled={!newEvent.title || !newEvent.date || !newEvent.time}
                      className="w-full bg-green-500 hover:bg-green-600"
                    >
                      일정 추가
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent className="pt-0 flex-1 flex flex-col">
            {/* 캘린더 헤더 */}
            <div className="flex items-center justify-between mb-6">
              <Button variant="ghost" size="sm" onClick={() => navigateMonth("prev")} className="p-2">
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <h3 className="text-xl font-semibold">
                {currentDate.toLocaleDateString("en-US", { month: "long", year: "numeric" })}
              </h3>
              <Button variant="ghost" size="sm" onClick={() => navigateMonth("next")} className="p-2">
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>

            {/* 요일 헤더 */}
            <div className="grid grid-cols-7 gap-2 mb-4">
              {weekDays.map((day) => (
                <div key={day} className="text-center text-sm font-medium text-gray-500 py-3">
                  {day}
                </div>
              ))}
            </div>

            {/* 캘린더 그리드 - 더 큰 셀 크기와 폰트 */}
            <div className="grid grid-cols-7 gap-2 flex-1">
              {days.map((day, index) => {
                const isSelected = selectedDate && day.date.toDateString() === selectedDate.toDateString()
                return (
                  <button
                    key={index}
                    onClick={() => setSelectedDate(day.date)}
                    className={`
                      relative p-3 text-base font-medium rounded-lg transition-colors h-16 flex items-center justify-center
                      ${day.isCurrentMonth ? "text-gray-900" : "text-gray-400"}
                      ${day.isToday ? "bg-green-100 text-green-800 font-bold" : ""}
                      ${isSelected ? "bg-green-500 text-white font-bold" : "hover:bg-gray-100"}
                      ${!day.isCurrentMonth ? "hover:bg-gray-50" : ""}
                    `}
                  >
                    {day.date.getDate()}
                    {day.hasEvents && (
                      <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                      </div>
                    )}
                  </button>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 우측: 카드 3개 - 1/3 공간 차지, 캘린더와 동일한 높이 */}
      <div className="lg:col-span-1 flex flex-col space-y-4 h-[700px]">
        {/* 일정 검색 - 1/3 높이 */}
        <Card className="rounded-xl border-0 shadow-sm bg-white flex-1">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <Search className="h-4 w-4 text-blue-600" />
              <span className="text-base font-semibold">일정 검색</span>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <Input
              placeholder="일정을 검색하세요..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="rounded-lg"
            />
          </CardContent>
        </Card>

        {/* 일정 조회 - 1/3 높이 */}
        <div className="flex-1">
          <ScheduleSidebar selectedDate={selectedDate} getEventsForDate={getEventsForDate} />
        </div>

        {/* 다가오는 이벤트 - 1/3 높이 */}
        <Card className="rounded-xl border-0 shadow-sm bg-white flex-1">
          <CardHeader className="pb-3">
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4 text-orange-600" />
              <span className="text-base font-semibold">다가오는 이벤트</span>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="text-sm text-gray-500">다가오는 이벤트가 없습니다</div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
