"use client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Instagram, FileText } from "lucide-react"
import { format } from "date-fns"
import type { AutomationTask } from "../types"

interface AiContentListProps {
  contents: AutomationTask[]
  onContentSelect: (content: AutomationTask) => void
}

export function AiContentList({ contents, onContentSelect }: AiContentListProps) {
  return (
    <Card className="rounded-xl border-0 shadow-sm bg-white">
      <CardHeader className="pb-3">
        <CardTitle className="text-base">AI 생성 콘텐츠</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[500px]">
          <div className="space-y-3">
            {contents.length > 0 ? (
              contents.map((content) => (
                <Card
                  key={content.task_id}
                  onClick={() => onContentSelect(content)}
                  className="hover:shadow-md cursor-pointer transition-all"
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2 text-sm font-semibold">
                        {content.task_data?.platform === "instagram" ? (
                          <>
                            <Instagram className="w-4 h-4 text-pink-500" />
                            <span>인스타그램</span>
                          </>
                        ) : (
                          <>
                            <FileText className="w-4 h-4 text-green-600" />
                            <span>네이버</span>
                          </>
                        )}
                      </div>
                      <span className="text-xs text-gray-400">
                        {format(new Date(content.created_at), "yyyy. M. d.")}
                      </span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-1">
                    <p className="font-semibold text-sm truncate">{content.title}</p>
              <p className="text-xs text-gray-500 line-clamp-2 whitespace-pre-wrap">
                {
                  typeof content.task_data?.full_content === "string" ? content.task_data?.full_content :
                  typeof content.task_data?.post_content === "string" ? content.task_data?.post_content :
                  typeof content.task_data?.content === "string" ? content.task_data?.content :
                  Array.isArray(content.task_data?.searched_hashtags)
                    ? content.task_data?.searched_hashtags.join(" ")
                    : "내용 없음"
                }
              </p>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="flex items-center justify-center h-[200px] text-gray-500 text-sm">
                생성된 콘텐츠가 없습니다
              </div>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}